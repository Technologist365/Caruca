caruca
======

Caruca is an open-source ecommerce website designed for beginners or the non-technical minded person.
