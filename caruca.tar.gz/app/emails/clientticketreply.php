To <?php echo $first.' '.$last; ?>,<br />
<br />
A reply has been added to your ticket #<?php echo $ticketid; ?>.<br />
<br />
<br />
Regards,<br />
<?php echo SYSTEM_NAME; ?><br />
<a href="<?php echo SYSTEM_URL; ?>"><?php echo SYSTEM_URL; ?></a>