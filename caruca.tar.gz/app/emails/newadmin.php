Hi, <?php echo $firstname; ?><br>
You have just been added as an administrator on <?php echo SYSTEM_NAME; ?>.
<br><br>
Please visit <a href="<?php echo SYSTEM_URL; ?>admin"><?php echo SYSTEM_NAME; ?>->Admin</a><br>
to login.<br><br>

Your credentials are:<br>
<?php echo $email; ?><br>
<?php echo $password; ?><br>
<br>
<br>
Regards,<br>
<?php echo SYSTEM_NAME; ?><br>
<a href="<?php echo SYSTEM_URL; ?>"><?php echo SYSTEM_URL; ?></a>