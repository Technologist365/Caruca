Dear <?php echo $first . ' ' . $last; ?>,<br />
Thank you for signing up to <?php echo SYSTEM_NAME; ?>!<br />
<br />
<b>Your sign in details are:</b><br />
Email: <?php echo $email; ?><br />
Pass: <?php echo $password; ?><br />
<br />
<br />
Regards,<br />
<?php echo SYSTEM_NAME; ?><br />
<a href="<?php echo SYSTEM_URL; ?>"><?php echo SYSTEM_URL; ?></a>
