Dear <?php echo $firstname; ?>,<br />
This is a notification to say you logged into your administration<br />
account on <?php echo SYSTEM_NAME; ?> at <?php echo date("d-m-Y H:i:s"); ?>.
<br />
<br />
Regards,<br />
<?php echo SYSTEM_NAME; ?><br />
<a href="<?php echo SYSTEM_URL; ?>"><?php echo SYSTEM_URL; ?></a>
