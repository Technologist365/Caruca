Dear <?php echo $first; ?>,<br />
You recently requested a password change to your account.<br />
<br />
If you did not authorize this, then please contact us as soon as possible.<br />
<br />
Regards,<br />
<?php echo SYSTEM_NAME; ?><br />
<a href="<?php echo SYSTEM_URL; ?>"><?php echo SYSTEM_URL; ?></a>