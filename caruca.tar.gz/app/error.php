<?php
/* I know the file is called error.php, but I wasn't making another
 * file just to hold success messages, so here they are. - Denver
 *
 * A little note about structure.
 * S--- is a success message.
 * T--- is a ticket message.
 * E--- is an error message.
 */
define("S001", "Your changes have been successfully updated!");

define("T001", "There are no tickets attached to your account.");