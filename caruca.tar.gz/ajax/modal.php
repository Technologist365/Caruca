<div id="info" class="modal fade">
	<div class="modal-dialog">
    	<div class="modal-content">
      		<div class="modal-header">
        		<button type="button" class="close" data-dismiss="modal">&times;</button>
        		<h4 id="modalLabel" class="modal-title"></h4>
      		</div>
      		<div class="modal-body">
        		<p id="main_modal_cntnt"></p>
      		</div>
      		<div class="modal-footer">
      			<p class="inblk">Last updated at <span class="text text-info" id="timestamp"></span> by <span class="text text-danger" id="author"></span></p>
        		<button type="button" class="btn btn-primary pull-right" data-dismiss="modal">Okay</button><div class="clearfix"></div>
      		</div>
    	</div>
  	</div>
</div>