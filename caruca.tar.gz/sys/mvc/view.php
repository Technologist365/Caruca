<?php

namespace sys\mvc;

class View
{
	
}

?>