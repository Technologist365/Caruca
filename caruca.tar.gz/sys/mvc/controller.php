<?php

namespace sys\mvc;

class controller {

}

?>