<?php

namespace sys\mvc;

class Application
{
	
}

?>